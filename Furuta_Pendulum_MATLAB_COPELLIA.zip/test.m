clc
clear all
close all

sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
        disp('Connected to remote API server');
        
        % Handles
        [returnCode,Arm_actuator]=sim.simxGetObjectHandle(clientID,'Arm_actuator',sim.simx_opmode_blocking);
        [returnCode,Pendulum_actuator]=sim.simxGetObjectHandle(clientID,'Pendulum_actuator',sim.simx_opmode_blocking);
        [returnCode,Force_sensor]=sim.simxGetObjectHandle(clientID,'Force_sensor',sim.simx_opmode_blocking);
        [returnCode,Pendulum]=sim.simxGetObjectHandle(clientID,'Pendulum',sim.simx_opmode_blocking);
        [returnCode,Arm]=sim.simxGetObjectHandle(clientID,'Arm',sim.simx_opmode_blocking);

      % Initial parameters/positions
        [returnCode,position_arm1]=sim.simxGetJointPosition(clientID,Arm_actuator,sim.simx_opmode_blocking)
        [returnCode,position_pen1]=sim.simxGetJointPosition(clientID,Pendulum_actuator,sim.simx_opmode_blocking)
        [returnCode,initial_angles_arm]=sim.simxGetObjectOrientation(clientID,Arm, -1,sim.simx_opmode_blocking)
        [returnCode,initial_angles_pen]=sim.simxGetObjectOrientation(clientID,Pendulum, -1,sim.simx_opmode_blocking)

        
       % Starting everything at 'home' position
        %[returnCode]=sim.simxSetJointPosition(clientID,Arm_actuator,0,sim.simx_opmode_blocking)
        %[returnCode]=sim.simxSetJointPosition(clientID,Pendulum_actuator,0,sim.simx_opmode_blocking)
        [returnCode]=sim.simxSetObjectOrientation(clientID,Pendulum, -1,[180,0,180],sim.simx_opmode_blocking)
        [returnCode]=sim.simxSetObjectOrientation(clientID, Arm, -1,[90,0,0],sim.simx_opmode_blocking)
        
        %[returnCode]=sim.simxSetJointTargetPosition(clientID,Arm_actuator,0,sim.simx_opmode_blocking)        
        %[returnCode]=sim.simxSetJointTargetPosition(clientID,Pendulum_actuator,90,sim.simx_opmode_blocking)        
        [returnCode]=sim.simxSetJointTargetVelocity(clientID,Arm_actuator,0.5,sim.simx_opmode_blocking)
        pause(5);
        [returnCode]=sim.simxSetJointTargetVelocity(clientID,Arm_actuator,0,sim.simx_opmode_blocking)
       
        for i=1:50
            [returnCode,position_arm]=sim.simxGetJointPosition(clientID,Arm_actuator,sim.simx_opmode_blocking)
            [returnCode,position_pen]=sim.simxGetJointPosition(clientID,Pendulum_actuator,sim.simx_opmode_blocking)
            [position,angles_pen]=sim.simxGetObjectOrientation(clientID,Pendulum, -1,sim.simx_opmode_blocking)
            [position,angles_arm]=sim.simxGetObjectOrientation(clientID,Arm, -1,sim.simx_opmode_blocking)
            Current_pendulum_angles = angles_pen * (180/pi);
            Current_arm_angles = angles_arm * (180/pi);
            disp(Current_pendulum_angles(2))
            pause(0.1); 
            setup_FURPEN;
            FB_pen_angels = K.*(Current_pendulum_angles*(pi/180));
            FB_arm_angels = K.*(Current_arm_angles*(pi/180));
            FB_arm = K*position_arm;
            FB_pendulum = K*position_pen;

            [returnCode]=sim.simxSetObjectOrientation(clientID,Pendulum, -1,FB_pen_angels,sim.simx_opmode_blocking)
            [returnCode]=sim.simxSetObjectOrientation(clientID,Pendulum, -1,FB_arm_angels,sim.simx_opmode_blocking)
            [returnCode]=sim.simxSetJointPosition(clientID,Pendulum_actuator,FB_pendulum,sim.simx_opmode_blocking)
            [returnCode]=sim.simxSetJointPosition(clientID,Arm_actuator,FB_arm,sim.simx_opmode_blocking)
        end
        %[returnCode]=sim.simxSetJointTargetPosition(clientID,Pendulum_actuator,90,sim.simx_opmode_blocking)        
        %[returnCode]=sim.simxSetObjectOrientation(clientID,Pendulum, sim.sim_handle_parent,initial_angles,sim.simx_opmode_blocking)
else
        disp('Failed connecting to remote API server');
end 

sim.delete(); % call the destructor!
disp('Program ended');
    
